import 'package:flutter/material.dart';

typedef FetchItems<T> = Future<List<T>> Function();

class ListScreen<T> extends StatefulWidget {
  const ListScreen({
    super.key,
    required this.title,
    required this.fetchItems,
    required this.getName,
    required this.getTags,
    required this.getRatingAvg,
    required this.getPriceLevel,
    required this.onTapItem,
    required this.onCreate,
    required this.onHome,
    required this.onBack,
    this.emptyMessageOverride,
    this.onFilters, // (por ahora opcional)
    this.onSort,    // (por ahora opcional)
  });

  // Identidad
  final String title;

  // Datos
  final FetchItems<T> fetchItems;

  // Adaptadores de UI (cómo extraer datos del item)
  final String Function(T item) getName;
  final List<String> Function(T item) getTags;
  final double? Function(T item) getRatingAvg;
  final String? Function(T item) getPriceLevel;

  // Acciones
  final void Function(T item) onTapItem;
  final VoidCallback onCreate;
  final VoidCallback onHome;
  final VoidCallback onBack;

  // Opcionales (para más adelante)
  final VoidCallback? onFilters;
  final VoidCallback? onSort;

  // Mensaje vacío
  final String? emptyMessageOverride;

  @override
  State<ListScreen<T>> createState() => _ListScreenState<T>();
}

class _ListScreenState<T> extends State<ListScreen<T>> {
  bool _loading = true;
  String? _error;
  List<T> _items = const [];

  @override
  void initState() {
    super.initState();
    _load(initial: true);
  }

  Future<void> _load({bool initial = false}) async {
    if (!mounted) return;
    setState(() {
      _error = null;
      if (initial) _loading = true;
    });

    try {
      final items = await widget.fetchItems();
      if (!mounted) return;
      setState(() {
        _items = items;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
      });
    } finally {
      if (!mounted) return;
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final emptyMsg = widget.emptyMessageOverride ??
        'No existen ${widget.title.toLowerCase()} actualmente';

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        centerTitle: false,
      ),
      body: Column(
        children: [
          // Barra superior secundaria (Filtros / Ordenar) - por ahora opcional
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: widget.onFilters, // null => deshabilitado
                    icon: const Icon(Icons.tune_rounded),
                    label: const Text('Filtros'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: widget.onSort, // null => deshabilitado
                    icon: const Icon(Icons.sort_rounded),
                    label: const Text('Ordenar'),
                  ),
                ),
              ],
            ),
          ),

          // Contenido principal
          Expanded(
            child: _buildContent(emptyMsg),
          ),
        ],
      ),
      bottomNavigationBar: _BottomActionsBar(
        onHome: widget.onHome,
        onCreate: widget.onCreate,
        onBack: widget.onBack,
      ),
    );
  }

  Widget _buildContent(String emptyMsg) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline_rounded, size: 36),
              const SizedBox(height: 10),
              Text(
                'Ha ocurrido un error al cargar el listado.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12),
              ),
              const SizedBox(height: 14),
              ElevatedButton.icon(
                onPressed: () => _load(initial: true),
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Reintentar'),
              ),
            ],
          ),
        ),
      );
    }

    if (_items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            emptyMsg,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16),
          ),
        ),
      );
    }

    // ✅ Pull-to-refresh:
    // - Estás arriba del todo
    // - Arrastras hacia abajo
    // - Aparece el indicador
    // - Al soltar, refresca
    return RefreshIndicator.adaptive(
      onRefresh: _load,
      child: ListView.separated(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        itemCount: _items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final item = _items[index];
          return _ListCard<T>(
            item: item,
            getName: widget.getName,
            getTags: widget.getTags,
            getRatingAvg: widget.getRatingAvg,
            getPriceLevel: widget.getPriceLevel,
            onTap: () => widget.onTapItem(item),
          );
        },
      ),
    );
  }
}

class _ListCard<T> extends StatelessWidget {
  const _ListCard({
    required this.item,
    required this.getName,
    required this.getTags,
    required this.getRatingAvg,
    required this.getPriceLevel,
    required this.onTap,
  });

  final T item;
  final String Function(T item) getName;
  final List<String> Function(T item) getTags;
  final double? Function(T item) getRatingAvg;
  final String? Function(T item) getPriceLevel;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final name = getName(item).trim();

    final tagsAll = getTags(item).map((t) => t.trim()).where((t) => t.isNotEmpty).toList();
    final tags = tagsAll.take(4).toList();
    final hasMore = tagsAll.length > 4;

    final tagsText = [
      ...tags,
      if (hasMore) '...',
    ].join(' · ');

    final rating = getRatingAvg(item);
    final ratingText = (rating == null) ? '--' : rating.toStringAsFixed(1);

    final price = (getPriceLevel(item) ?? '').trim();

    return Material(
      color: Theme.of(context).cardColor,
      borderRadius: BorderRadius.circular(14),
      elevation: 1,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Izquierda: nombre + tags
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      tagsText,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        color: Theme.of(context).textTheme.bodySmall?.color,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 12),

              // Derecha: rating + price
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.star_rounded, size: 18),
                      const SizedBox(width: 4),
                      Text(ratingText, style: const TextStyle(fontWeight: FontWeight.w600)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    price,
                    style: TextStyle(
                      fontSize: 13,
                      color: Theme.of(context).textTheme.bodySmall?.color,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomActionsBar extends StatelessWidget {
  const _BottomActionsBar({
    required this.onHome,
    required this.onCreate,
    required this.onBack,
  });

  final VoidCallback onHome;
  final VoidCallback onCreate;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        child: Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: onHome,
                icon: const Icon(Icons.home_rounded),
                label: const Text('Home'),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              height: 46,
              width: 64,
              child: ElevatedButton(
                onPressed: onCreate,
                child: const Icon(Icons.add_rounded, size: 26),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: onBack,
                icon: const Icon(Icons.arrow_back_rounded),
                label: const Text('Back'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
