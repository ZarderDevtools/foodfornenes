// lib/screens/places/places_list_screen.dart

import 'package:flutter/material.dart';

import '../../config/network/paged_result.dart';
import '../../models/place.dart';
import '../../models/place_list_query.dart';
import '../../repositories/places_repository.dart';
import '../../services/api_client.dart';
import '../../services/places_service.dart';

class PlacesListScreen extends StatefulWidget {
  /// UUID del PlaceType base (ej: restaurante).
  final String placeTypeId;

  /// Título de la pantalla (ej: "Restaurantes")
  final String title;

  const PlacesListScreen({
    super.key,
    required this.placeTypeId,
    required this.title,
  });

  @override
  State<PlacesListScreen> createState() => _PlacesListScreenState();
}

class _PlacesListScreenState extends State<PlacesListScreen> {
  final _scrollController = ScrollController();

  ApiClient? _api;
  PlacesService? _service;

  bool _loading = true;
  bool _loadingMore = false;
  String? _error;

  final List<Place> _items = [];

  // Query actual (luego lo ampliarás con filtros/search/ordering)
  late PlaceListQuery _query;

  @override
  void initState() {
    super.initState();
    _query = PlaceListQuery(placeTypeId: widget.placeTypeId, page: 1);

    _init();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    try {
      final api = await ApiClient.create();
      final repo = PlacesRepository(api);
      final service = PlacesService(repo);

      setState(() {
        _api = api;
        _service = service;
      });

      await _loadFirst();
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _loadFirst() async {
    final service = _service;
    if (service == null) return;

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final PagedResult<Place> res = await service.loadFirstPage(_query);
      setState(() {
        _items
          ..clear()
          ..addAll(res.results);
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _refresh() async {
    final service = _service;
    if (service == null) return;

    try {
      final res = await service.refresh();
      setState(() {
        _items
          ..clear()
          ..addAll(res.results);
      });
    } catch (e) {
      // no matamos la UI por un refresh fallido
      setState(() => _error = e.toString());
    }
  }

  void _onScroll() {
    if (_loading || _loadingMore) return;
    final service = _service;
    if (service == null || !service.hasNext) return;

    // Cuando estás cerca del final, carga más
    final threshold = 300.0;
    final maxScroll = _scrollController.position.maxScrollExtent;
    final current = _scrollController.position.pixels;

    if (maxScroll - current <= threshold) {
      _loadMore();
    }
  }

  Future<void> _loadMore() async {
    final service = _service;
    if (service == null || !service.hasNext) return;

    setState(() => _loadingMore = true);

    try {
      final res = await service.loadNextPage();
      if (res.results.isNotEmpty) {
        setState(() => _items.addAll(res.results));
      }
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final serviceReady = _api != null && _service != null;

    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: !serviceReady
          ? const Center(child: CircularProgressIndicator())
          : _loading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? _ErrorView(
                      error: _error!,
                      onRetry: _loadFirst,
                    )
                  : RefreshIndicator(
                      onRefresh: _refresh,
                      child: ListView.separated(
                        controller: _scrollController,
                        physics: const AlwaysScrollableScrollPhysics(),
                        itemCount: _items.length + 1, // +1 para loader final
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, index) {
                          if (index == _items.length) {
                            // Footer loader
                            if (_loadingMore) {
                              return const Padding(
                                padding: EdgeInsets.all(16),
                                child: Center(child: CircularProgressIndicator()),
                              );
                            }
                            return const SizedBox(height: 24);
                          }

                          final p = _items[index];

                          // Lo que hablamos:
                          final ratingText = p.avgRating == null
                              ? "--"
                              : p.avgRating!.toStringAsFixed(1);

                          final priceText = p.priceRange; // "€", "€€", etc.

                          return ListTile(
                            title: Text(p.name),
                            subtitle: Text('Rating: $ratingText · Precio: $priceText'),
                          );
                        },
                      ),
                    ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String error;
  final VoidCallback onRetry;

  const _ErrorView({
    required this.error,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Error cargando places:\n$error',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: onRetry,
              child: const Text('Reintentar'),
            ),
          ],
        ),
      ),
    );
  }
}
